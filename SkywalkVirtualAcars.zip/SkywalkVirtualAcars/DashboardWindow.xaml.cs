using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace SkywalkVirtualAcars
{
    public static class SessionManager
    {
        public static string CurrentUsername { get; set; } = "admin";
        public static string SimbriefUsername { get; set; } = "olcayalkaya";
        public static string UserRole { get; set; } = "admin";
    }

    public class UserSessionData
    {
        public string Username { get; set; } = "admin";
        public string Bio { get; set; } = "Sanal havacılık tutkunu, Airbus A320 ve A321 ailelerinde uçmaktan keyif alan kıdemli kaptan pilot.";
        public string AvatarPath { get; set; } = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&amp;w=200&amp;auto=format&amp;fit=crop";
        public double WalletBalance { get; set; } = 12450.0;
        public bool IsAdmin => Username.Equals("admin", StringComparison.OrdinalIgnoreCase) || Username.Equals("SVK0001", StringComparison.OrdinalIgnoreCase) || SessionManager.UserRole.Equals("admin", StringComparison.OrdinalIgnoreCase);
    }

    public class UserAccountRecord
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string SimbriefUsername { get; set; } = "";
        public string Role { get; set; } = "newbie";
        public bool IsApproved { get; set; } = false;
    }

    public class TourLegModel
    {
        public int LegNumber { get; set; }
        public string Origin { get; set; } = "";
        public string Destination { get; set; } = "";
        public string Conditions { get; set; } = "";
    }

    public class VirtualTourModel
    {
        public string TourId { get; set; } = Guid.NewGuid().ToString();
        public string TourName { get; set; } = "";
        public string Description { get; set; } = "";
        public string Award { get; set; } = "";
        public int LegsCount => Legs?.Count ?? 0;
        public List<TourLegModel> Legs { get; set; } = new List<TourLegModel>();
    }

    public class AdminPilotManagementModel
    {
        public string Username { get; set; } = "";
        public string SimbriefUsername { get; set; } = "";
        public string Role { get; set; } = "newbie";
        public bool IsApproved { get; set; } = true;
        public string StatusButtonText => IsApproved ? "🟢 Aktif (Dondur)" : "🔴 Askıda (Aktif Yap)";
        public string StatusButtonColor => IsApproved ? "#10b981" : "#f59e0b";
    }

    public class VirtualPilot
    {
        public string Callsign { get; set; } = "";
        public string FullName { get; set; } = "";
        public string Rank { get; set; } = "";
        public string ShortBio { get; set; } = "";
        public string TotalHours { get; set; } = "00:00 hrs";
        public string AvgLandingRate { get; set; } = "-140 fpm";
        public int TotalFlights { get; set; } = 0;
        public double Wallet { get; set; } = 10000;
        public string AvatarUrl { get; set; } = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&amp;w=200&amp;auto=format&amp;fit=crop";
        public List<BadgeItem> Badges { get; set; } = new List<BadgeItem>();
        public List<AcarsFlightLog> FlightLogs { get; set; } = new List<AcarsFlightLog>();
    }

    public class AcarsFlightLog
    {
        public string FlightNumber { get; set; } = "";
        public string Origin { get; set; } = "";
        public string Destination { get; set; } = "";
        public string Aircraft { get; set; } = "";
        public string FlightTime { get; set; } = "";
        public string FuelUsed { get; set; } = "";
        public string LandingRate { get; set; } = "";
        public string LandingStatusColor { get; set; } = "#10b981";
        public string Date { get; set; } = "";
        public string Status { get; set; } = "ACARS APPROVED";
    }

    public class BadgeItem
    {
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public string Icon { get; set; } = "🏆";
    }

    public partial class DashboardWindow : Window
    {
        private static readonly HttpClient httpClient = new HttpClient();
        private static readonly string accountsDbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "pilot_accounts.json");
        private static readonly string toursDbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "virtual_tours.json");
        
        private string UserSettingsFilePath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"pilot_settings_{currentUserData.Username.ToLower()}.json");
        private string UserLogsFilePath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"pilot_flightlogs_{currentUserData.Username.ToLower()}.json");

        private UserSessionData currentUserData = new UserSessionData();
        private List<VirtualTourModel> loadedToursList = new List<VirtualTourModel>();
        private List<TourLegModel> tempLegsForNewTour = new List<TourLegModel>();

        private bool isFlightActive = false;

        private ObservableCollection<AcarsFlightLog> acarsLogsList = new ObservableCollection<AcarsFlightLog>();
        private List<VirtualPilot> virtualPilotsList = new List<VirtualPilot>();

        public DashboardWindow()
        {
            InitializeComponent();
            
            if (!string.IsNullOrEmpty(SessionManager.CurrentUsername))
            {
                currentUserData.Username = SessionManager.CurrentUsername;
            }

            LoadPersistentData();
            LoadToursData();
            LoadAcarsLogs();
            ApplyRoleBasedSecurity();
            LoadVirtualPilots();
            LoadProfileData();
            UpdateWalletDisplay();
            LoadPendingUsersForAdmin();
        }

        private void LoadPersistentData()
        {
            try
            {
                string path = UserSettingsFilePath;
                if (File.Exists(path))
                {
                    string json = File.ReadAllText(path);
                    var data = JsonSerializer.Deserialize<UserSessionData>(json);
                    if (data != null) currentUserData = data;
                }
                else
                {
                    currentUserData.WalletBalance = 10000.0;
                    SavePersistentData();
                }

                if (!string.IsNullOrEmpty(SessionManager.CurrentUsername))
                {
                    currentUserData.Username = SessionManager.CurrentUsername;
                }
            }
            catch { }
        }

        private void SavePersistentData()
        {
            try
            {
                string json = JsonSerializer.Serialize(currentUserData, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(UserSettingsFilePath, json);
            }
            catch { }
        }

        private void LoadToursData()
        {
            loadedToursList = new List<VirtualTourModel>();
            try
            {
                if (File.Exists(toursDbPath))
                {
                    string json = File.ReadAllText(toursDbPath);
                    var list = JsonSerializer.Deserialize<List<VirtualTourModel>>(json);
                    if (list != null) loadedToursList = list;
                }

                if (loadedToursList.Count == 0)
                {
                    loadedToursList.Add(new VirtualTourModel
                    {
                        TourName = "Anadolu Rallisi 2026",
                        Description = "Türkiye'nin büyüleyici havalimanlarını kapsayan geleneksel ralli turu.",
                        Award = "Anadolu Master Rozeti",
                        Legs = new List<TourLegModel>
                        {
                            new TourLegModel { LegNumber = 1, Origin = "LTFM", Destination = "LTAI", Conditions = "Max FL320" },
                            new TourLegModel { LegNumber = 2, Origin = "LTAI", Destination = "LTBJ", Conditions = "VFR / IFR" }
                        }
                    });
                    SaveToursData();
                }
            }
            catch { }
            icToursList.ItemsSource = loadedToursList;
            icAdminToursList.ItemsSource = loadedToursList;
        }

        private void SaveToursData()
        {
            try
            {
                string json = JsonSerializer.Serialize(loadedToursList, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(toursDbPath, json);
            }
            catch { }
        }

        private void LoadAcarsLogs()
        {
            acarsLogsList = new ObservableCollection<AcarsFlightLog>();
            try
            {
                string path = UserLogsFilePath;
                if (File.Exists(path))
                {
                    string json = File.ReadAllText(path);
                    var logs = JsonSerializer.Deserialize<List<AcarsFlightLog>>(json);
                    if (logs != null) foreach (var log in logs) acarsLogsList.Add(log);
                }
                if (acarsLogsList.Count == 0)
                {
                    acarsLogsList.Add(new AcarsFlightLog { FlightNumber = currentUserData.Username.ToUpper() + "101", Origin = "LTFM", Destination = "LTAI", Aircraft = "A320-200", FlightTime = "01:15 hrs", FuelUsed = "3,250 KG", LandingRate = "-112 fpm", Date = "20.09.2026 14:20" });
                    SaveAcarsLogs();
                }
            }
            catch { }
            icAcarsFlightLogs.ItemsSource = acarsLogsList;
            lblTotalAcarsFlights.Text = $"{acarsLogsList.Count} Uçuş";
            lblAvgLandingRate.Text = "-138 fpm";
        }

        private void SaveAcarsLogs()
        {
            try
            {
                string json = JsonSerializer.Serialize(acarsLogsList, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(UserLogsFilePath, json);
            }
            catch { }
        }

        private void ApplyRoleBasedSecurity()
        {
            if (currentUserData.IsAdmin)
            {
                btnAdminMenu.Visibility = Visibility.Visible;
                lblSidebarUserRole.Text = "System Administrator • Admin";
                txtWelcomeUser.Text = $"Hoş Geldiniz, Sistem Yöneticisi ({currentUserData.Username})";
            }
            else
            {
                btnAdminMenu.Visibility = Visibility.Collapsed;
                lblSidebarUserRole.Text = $"{currentUserData.Username} • Pilot";
                txtWelcomeUser.Text = $"Hoş Geldiniz, Kaptan {currentUserData.Username}";
            }

            txtSimbriefUsername.Text = SessionManager.SimbriefUsername;
            if (txtProfileUsernameTitle != null) txtProfileUsernameTitle.Text = currentUserData.Username;
            lblSidebarPilotName.Text = $"{currentUserData.Username}";
        }

        private void UpdateWalletDisplay()
        {
            txtPilotWallet.Text = $"${currentUserData.WalletBalance:N0}";
        }

        private void LoadPendingUsersForAdmin()
        {
            try
            {
                if (File.Exists(accountsDbPath))
                {
                    string json = File.ReadAllText(accountsDbPath);
                    var accounts = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                    if (accounts != null)
                    {
                        var pendingList = new List<UserAccountRecord>();
                        foreach (var acc in accounts) if (!acc.IsApproved) pendingList.Add(acc);
                        icPendingUsers.ItemsSource = pendingList;
                    }
                }
            }
            catch { }
        }

        private void ApproveUser_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string username)
            {
                try
                {
                    if (File.Exists(accountsDbPath))
                    {
                        string json = File.ReadAllText(accountsDbPath);
                        var accounts = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                        if (accounts != null)
                        {
                            foreach (var acc in accounts) if (acc.Username.Equals(username, StringComparison.OrdinalIgnoreCase)) { acc.IsApproved = true; acc.Role = "Captain"; }
                            File.WriteAllText(accountsDbPath, JsonSerializer.Serialize(accounts, new JsonSerializerOptions { WriteIndented = true }));
                            LoadPendingUsersForAdmin();
                            LoadVirtualPilots();
                            MessageBox.Show($"{username} onaylandı!", "Başarılı");
                        }
                    }
                }
                catch { }
            }
        }

        private void LoadAllPilotsForAdminControl()
        {
            try
            {
                if (File.Exists(accountsDbPath))
                {
                    string json = File.ReadAllText(accountsDbPath);
                    var accounts = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                    if (accounts != null)
                    {
                        var list = new List<AdminPilotManagementModel>();
                        foreach (var acc in accounts)
                        {
                            list.Add(new AdminPilotManagementModel
                            {
                                Username = acc.Username,
                                SimbriefUsername = acc.SimbriefUsername,
                                Role = acc.Role,
                                IsApproved = acc.IsApproved
                            });
                        }
                        icAdminAllPilots.ItemsSource = list;
                    }
                }
            }
            catch { }
        }

        private void AdminSavePilotRank_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string username)
            {
                try
                {
                    if (File.Exists(accountsDbPath))
                    {
                        string json = File.ReadAllText(accountsDbPath);
                        var accounts = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                        if (accounts != null)
                        {
                            foreach (var acc in accounts)
                            {
                                if (acc.Username.Equals(username, StringComparison.OrdinalIgnoreCase))
                                {
                                    if (btn.DataContext is AdminPilotManagementModel model)
                                    {
                                        acc.Role = model.Role;
                                    }
                                }
                            }
                            File.WriteAllText(accountsDbPath, JsonSerializer.Serialize(accounts, new JsonSerializerOptions { WriteIndented = true }));
                            MessageBox.Show($"{username} rütbesi güncellendi!", "Başarılı");
                            LoadAllPilotsForAdminControl();
                            LoadVirtualPilots();
                        }
                    }
                }
                catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
            }
        }

        private void AdminToggleSuspendPilot_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string username)
            {
                if (username.Equals("admin", StringComparison.OrdinalIgnoreCase)) return;
                try
                {
                    if (File.Exists(accountsDbPath))
                    {
                        string json = File.ReadAllText(accountsDbPath);
                        var accounts = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                        if (accounts != null)
                        {
                            foreach (var acc in accounts) if (acc.Username.Equals(username, StringComparison.OrdinalIgnoreCase)) acc.IsApproved = !acc.IsApproved;
                            File.WriteAllText(accountsDbPath, JsonSerializer.Serialize(accounts, new JsonSerializerOptions { WriteIndented = true }));
                            LoadAllPilotsForAdminControl();
                            LoadPendingUsersForAdmin();
                        }
                    }
                }
                catch { }
            }
        }

        private void AdminDeletePilot_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string username)
            {
                if (username.Equals("admin", StringComparison.OrdinalIgnoreCase)) return;
                if (MessageBox.Show($"{username} silinsin mi?", "Onay", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    try
                    {
                        if (File.Exists(accountsDbPath))
                        {
                            string json = File.ReadAllText(accountsDbPath);
                            var accounts = JsonSerializer.Deserialize<List<UserAccountRecord>>(json);
                            if (accounts != null)
                            {
                                accounts.RemoveAll(a => a.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
                                File.WriteAllText(accountsDbPath, JsonSerializer.Serialize(accounts, new JsonSerializerOptions { WriteIndented = true }));
                            }
                        }
                        LoadAllPilotsForAdminControl();
                        LoadPendingUsersForAdmin();
                    }
                    catch { }
                }
            }
        }

        private void AdminDeleteTour_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string tourId)
            {
                var tourToDel = loadedToursList.Find(t => t.TourId == tourId);
                string tourName = tourToDel?.TourName ?? "Seçilen Tur";

                if (MessageBox.Show($"'{tourName}' adlı turu ve tüm bacaklarını silmek istediğinize emin misiniz?", "Onay", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    try
                    {
                        loadedToursList.RemoveAll(t => t.TourId == tourId);
                        SaveToursData();
                        LoadToursData();
                        icAdminToursList.ItemsSource = null;
                        icAdminToursList.ItemsSource = loadedToursList;
                        MessageBox.Show("Tur silindi.", "Başarılı");
                    }
                    catch (Exception ex) { MessageBox.Show("Hata: " + ex.Message); }
                }
            }
        }

        private void LoadVirtualPilots()
        {
            virtualPilotsList = new List<VirtualPilot>();
            try
            {
                if (File.Exists(accountsDbPath))
                {
                    string json = File.ReadAllText(accountsDbPath);
                    var accounts = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                    if (accounts != null)
                    {
                        foreach (var acc in accounts)
                        {
                            if (acc.IsApproved)
                            {
                                virtualPilotsList.Add(new VirtualPilot
                                {
                                    Callsign = acc.Username.ToUpper(),
                                    FullName = acc.Username,
                                    Rank = acc.Role,
                                    ShortBio = $"SimBrief: {acc.SimbriefUsername}",
                                    TotalHours = "12:00 hrs",
                                    AvgLandingRate = "-135 fpm",
                                    TotalFlights = 5,
                                    Wallet = 12000,
                                    AvatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&amp;w=200&amp;auto=format&amp;fit=crop"
                                });
                            }
                        }
                    }
                }
            }
            catch { }
            icVirtualPilots.ItemsSource = virtualPilotsList;
        }

        private void LoadProfileData() { }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) this.DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();
        private void MinimizeButton_Click(object sender, RoutedEventArgs e) => this.WindowState = WindowState.Minimized;

        private void HideAllPanels()
        {
            panelAnasayfa.Visibility = Visibility.Collapsed;
            panelUcusYap.Visibility = Visibility.Collapsed;
            panelUcusKayitlarim.Visibility = Visibility.Collapsed;
            panelPilotlar.Visibility = Visibility.Collapsed;
            panelPilotFullProfile.Visibility = Visibility.Collapsed;
            panelTurlar.Visibility = Visibility.Collapsed;
            panelTourDetail.Visibility = Visibility.Collapsed;
            panelSirket.Visibility = Visibility.Collapsed;
            panelAdmin.Visibility = Visibility.Collapsed;
            panelAdminPilotKontrol.Visibility = Visibility.Collapsed;
            panelAdminTurEkle.Visibility = Visibility.Collapsed;
            panelAdminTurSil.Visibility = Visibility.Collapsed;
            panelAdminTarifeliSefer.Visibility = Visibility.Collapsed;
            panelAdminFilo.Visibility = Visibility.Collapsed;
            panelProfile.Visibility = Visibility.Collapsed;
            panelEkonomi.Visibility = Visibility.Collapsed;
            panelEmlak.Visibility = Visibility.Collapsed;
            panelArsa.Visibility = Visibility.Collapsed;
            panelArac.Visibility = Visibility.Collapsed;
            panelBorsa.Visibility = Visibility.Collapsed;
        }

        private void NavAnasayfa_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelAnasayfa.Visibility = Visibility.Visible; txtPageTitle.Text = "ANASAYFA"; }
        private void NavUcusYap_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelUcusYap.Visibility = Visibility.Visible; txtPageTitle.Text = "UÇUŞ YAP"; }
        private void NavUcusKayitlarim_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelUcusKayitlarim.Visibility = Visibility.Visible; txtPageTitle.Text = "UÇUŞ KAYITLARIM"; LoadAcarsLogs(); }
        private void NavPilotlar_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelPilotlar.Visibility = Visibility.Visible; txtPageTitle.Text = "İSTATİSTİKLER — PİLOTLAR"; LoadVirtualPilots(); }
        private void NavTurlar_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelTurlar.Visibility = Visibility.Visible; txtPageTitle.Text = "TURLAR & ETKİNLİKLER"; LoadToursData(); }
        private void NavSirket_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelSirket.Visibility = Visibility.Visible; txtPageTitle.Text = "İSTATİSTİKLER — ŞİRKET"; }
        
        private void NavAdmin_Click(object sender, RoutedEventArgs e) 
        { 
            if (!currentUserData.IsAdmin) { MessageBox.Show("Yetkisiz erişim!"); return; }
            HideAllPanels(); panelAdmin.Visibility = Visibility.Visible; txtPageTitle.Text = "ADMİN YÖNETİM MERKEZİ"; 
            scrollNormalMenu.Visibility = Visibility.Collapsed;
            panelAdminSidebar.Visibility = Visibility.Visible;
            btnAdminExit.Visibility = Visibility.Visible;
            LoadPendingUsersForAdmin();
        }

        private void BtnViewTourDetail_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string tourId)
            {
                var tour = loadedToursList.Find(t => t.TourId == tourId);
                if (tour != null)
                {
                    HideAllPanels();
                    panelTourDetail.Visibility = Visibility.Visible;
                    txtPageTitle.Text = $"TUR DETAYI — {tour.TourName}";
                    txtTourDetailTitle.Text = tour.TourName;
                    txtTourDetailDesc.Text = $"{tour.Description} • Ödül: {tour.Award}";
                    icTourLegsList.ItemsSource = tour.Legs;
                }
            }
        }

        private void BtnBackToTours_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            panelTurlar.Visibility = Visibility.Visible;
            txtPageTitle.Text = "TURLAR & ETKİNLİKLER";
        }

        private void AdminMenuPilotKontrol_Click(object sender, RoutedEventArgs e) 
        { 
            HideAllPanels(); 
            panelAdminPilotKontrol.Visibility = Visibility.Visible; 
            txtPageTitle.Text = "YÖNETİM — PİLOT KONTROLÜ"; 
            LoadAllPilotsForAdminControl();
        }
        
        private void AdminMenuTurEkle_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            panelAdminTurEkle.Visibility = Visibility.Visible;
            txtPageTitle.Text = "YÖNETİM — TUR EKLEME";
            tempLegsForNewTour.Clear();
            lbTempLegs.ItemsSource = null;
        }

        private void AdminMenuTurSil_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            panelAdminTurSil.Visibility = Visibility.Visible;
            txtPageTitle.Text = "YÖNETİM — TUR SİLME";
            LoadToursData();
            icAdminToursList.ItemsSource = loadedToursList;
        }

        private void AdminAddLegToTour_Click(object sender, RoutedEventArgs e)
        {
            string origin = txtLegOrigin.Text.Trim().ToUpper();
            string dest = txtLegDest.Text.Trim().ToUpper();
            string cond = txtLegCond.Text.Trim();

            if (string.IsNullOrEmpty(origin) || string.IsNullOrEmpty(dest))
            {
                MessageBox.Show("Kalkış ve varış havalimanı ICAO kodları boş olamaz!");
                return;
            }

            tempLegsForNewTour.Add(new TourLegModel
            {
                LegNumber = tempLegsForNewTour.Count + 1,
                Origin = origin,
                Destination = dest,
                Conditions = string.IsNullOrEmpty(cond) ? "Standart IFR" : cond
            });

            lbTempLegs.ItemsSource = null;
            lbTempLegs.ItemsSource = tempLegsForNewTour;
            txtLegOrigin.Clear(); txtLegDest.Clear(); txtLegCond.Clear();
        }

        private void AdminSaveNewTour_Click(object sender, RoutedEventArgs e)
        {
            string tName = txtAdminTourName.Text.Trim();
            string tDesc = txtAdminTourDesc.Text.Trim();
            string tAward = txtAdminTourAward.Text.Trim();

            if (string.IsNullOrEmpty(tName) || tempLegsForNewTour.Count == 0)
            {
                MessageBox.Show("Lütfen tur adını girin ve en az 1 bacak ekleyin!", "Eksik Bilgi", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            loadedToursList.Add(new VirtualTourModel
            {
                TourName = tName,
                Description = tDesc,
                Award = string.IsNullOrEmpty(tAward) ? "Özel Tur Rozeti" : tAward,
                Legs = new List<TourLegModel>(tempLegsForNewTour)
            });

            SaveToursData();
            MessageBox.Show($"'{tName}' adlı tur başarıyla yayınlandı!", "Başarılı", MessageBoxButton.OK, MessageBoxImage.Information);
            
            txtAdminTourName.Clear(); txtAdminTourDesc.Clear(); txtAdminTourAward.Clear();
            tempLegsForNewTour.Clear(); lbTempLegs.ItemsSource = null;
        }

        private void AdminMenuTarifeliSefer_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelAdminTarifeliSefer.Visibility = Visibility.Visible; txtPageTitle.Text = "YÖNETİM — TARİFELİ SEFER"; }
        private void AdminMenuFilo_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelAdminFilo.Visibility = Visibility.Visible; txtPageTitle.Text = "YÖNETİM — FİLO YÖNETİMİ"; }

        private void AdminExit_Click(object sender, RoutedEventArgs e)
        {
            panelAdminSidebar.Visibility = Visibility.Collapsed;
            btnAdminExit.Visibility = Visibility.Collapsed;
            scrollNormalMenu.Visibility = Visibility.Visible;
            HideAllPanels(); panelAnasayfa.Visibility = Visibility.Visible; txtPageTitle.Text = "ANASAYFA";
        }

        private void NavProfile_Click(object sender, MouseButtonEventArgs e) { HideAllPanels(); panelProfile.Visibility = Visibility.Visible; txtPageTitle.Text = "PİLOT PROFİLİ"; }
        private void BtnOpenEconomy_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelEkonomi.Visibility = Visibility.Visible; txtPageTitle.Text = "EKONOMİ MERKEZİ"; }
        private void BtnBackToPilots_Click(object sender, RoutedEventArgs e) { HideAllPanels(); panelPilotlar.Visibility = Visibility.Visible; }

        private void BtnViewPilotProfile_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string callsign)
            {
                var pilot = virtualPilotsList.Find(p => p.Callsign.Equals(callsign, StringComparison.OrdinalIgnoreCase));
                if (pilot != null)
                {
                    HideAllPanels();
                    panelPilotFullProfile.Visibility = Visibility.Visible;
                    txtPageTitle.Text = $"PİLOT PROFİLİ — {pilot.Callsign}";
                    txtOtherName.Text = pilot.FullName;
                    txtOtherCallsignRank.Text = $"{pilot.Callsign} • {pilot.Rank}";
                    txtOtherBio.Text = pilot.ShortBio;
                }
            }
        }

        private void NavStatsToggle_Click(object sender, RoutedEventArgs e)
        {
            if (panelStatsSubMenu.Visibility == Visibility.Visible) { panelStatsSubMenu.Visibility = Visibility.Collapsed; btnStatsToggle.Content = "📊   İstatistikler  ▾"; }
            else { panelStatsSubMenu.Visibility = Visibility.Visible; btnStatsToggle.Content = "📊   İstatistikler  ▴"; }
        }

        private void NavLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Oturumu kapatmak istediğinize emin misiniz?", "Oturumu Kapat", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            { new MainWindow().Show(); this.Close(); }
        }

        private async void BtnFetchSimbrief_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string url = $"https://www.simbrief.com/api/xml.fetch.2.php?username={SessionManager.SimbriefUsername}";
                string xmlData = await httpClient.GetStringAsync(url);
                
                containerOfpDetails.Visibility = Visibility.Visible;
                panelNoOfpWarning.Visibility = Visibility.Collapsed;
                MessageBox.Show("SimBrief uçuş planı başarıyla çekildi!", "Başarılı", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("SimBrief verisi çekilemedi: " + ex.Message, "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnStartAcarsFlight_Click(object sender, RoutedEventArgs e)
        {
            isFlightActive = true;
            
            // Simüle edilmiş uçuş ve iniş kaydı
            acarsLogsList.Insert(0, new AcarsFlightLog
            {
                FlightNumber = currentUserData.Username.ToUpper() + "303",
                Origin = "LTFM",
                Destination = "LTAI",
                Aircraft = "A320-200",
                FlightTime = "01:20 hrs",
                FuelUsed = "3,800 KG",
                LandingRate = "-125 fpm",
                LandingStatusColor = "#10b981",
                Date = DateTime.Now.ToString("dd.MM.yyyy HH:mm"),
                Status = "ACARS COMPLETED"
            });
            SaveAcarsLogs();

            currentUserData.WalletBalance += 1500.0;
            SavePersistentData();
            UpdateWalletDisplay();

            MessageBox.Show("ACARS Uçuşu tamamlandı ve kayıtlarımıza işlendi!", "Uçuş Başarılı", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}