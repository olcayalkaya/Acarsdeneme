﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace SkywalkVirtualAcars
{
    public partial class App : Application
    {
    }
}