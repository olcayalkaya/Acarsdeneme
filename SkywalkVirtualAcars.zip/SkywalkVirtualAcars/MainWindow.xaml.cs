﻿using System;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace SkywalkVirtualAcars
{
    public partial class MainWindow : Window
    {
        private static readonly string dbFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "pilot_accounts.json");

        public MainWindow()
        {
            InitializeComponent();
            EnsureAdminAccountExists();
        }

        private void EnsureAdminAccountExists()
        {
            try
            {
                if (!File.Exists(dbFilePath))
                {
                    var defaultAdmin = new UserAccountRecord
                    {
                        Username = "admin",
                        Password = "admin",
                        SimbriefUsername = "olcayalkaya",
                        Role = "admin",
                        IsApproved = true
                    };
                    File.WriteAllText(dbFilePath, JsonSerializer.Serialize(new[] { defaultAdmin }, new JsonSerializerOptions { WriteIndented = true }));
                }
            }
            catch { }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left) this.DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();

        private void TabLogin_Click(object sender, RoutedEventArgs e)
        {
            panelLoginForm.Visibility = Visibility.Visible;
            panelRegisterForm.Visibility = Visibility.Collapsed;
            tabLoginBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2563eb"));
            tabRegisterBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#334155"));
        }

        private void TabRegister_Click(object sender, RoutedEventArgs e)
        {
            panelLoginForm.Visibility = Visibility.Collapsed;
            panelRegisterForm.Visibility = Visibility.Visible;
            tabRegisterBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#2563eb"));
            tabLoginBtn.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#334155"));
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string user = txtLoginUser.Text.Trim();
            string pass = txtLoginPass.Password.Trim();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Lütfen kullanıcı adı ve şifre giriniz.", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                if (File.Exists(dbFilePath))
                {
                    string json = File.ReadAllText(dbFilePath);
                    var accounts = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                    if (accounts != null)
                    {
                        foreach (var acc in accounts)
                        {
                            if (acc.Username.Equals(user, StringComparison.OrdinalIgnoreCase) && acc.Password == pass)
                            {
                                if (!acc.IsApproved)
                                {
                                    MessageBox.Show("Hesabınız henüz bir sistem yöneticisi tarafından onaylanmamıştır! Lütfen admin onayını bekleyin.", "Onay Bekliyor", MessageBoxButton.OK, MessageBoxImage.Warning);
                                    return;
                                }

                                SessionManager.CurrentUsername = acc.Username;
                                SessionManager.SimbriefUsername = string.IsNullOrEmpty(acc.SimbriefUsername) ? "olcayalkaya" : acc.SimbriefUsername;
                                SessionManager.UserRole = acc.Role;

                                new DashboardWindow().Show();
                                this.Close();
                                return;
                            }
                        }
                    }
                }
                MessageBox.Show("Geçersiz kullanıcı adı veya şifre!", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Giriş hatası: " + ex.Message);
            }
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            string user = txtRegUser.Text.Trim();
            string pass = txtRegPass.Password.Trim();
            string simbrief = txtRegSimbrief.Text.Trim();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(simbrief))
            {
                MessageBox.Show("Lütfen tüm alanları doldurunuz (SimBrief kullanıcı adı dahil).", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var list = new System.Collections.Generic.List<UserAccountRecord>();
                if (File.Exists(dbFilePath))
                {
                    string json = File.ReadAllText(dbFilePath);
                    var existing = JsonSerializer.Deserialize<UserAccountRecord[]>(json);
                    if (existing != null) list.AddRange(existing);
                }

                if (list.Exists(x => x.Username.Equals(user, StringComparison.OrdinalIgnoreCase)))
                {
                    MessageBox.Show("Bu kullanıcı adı zaten kullanımda!", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                var newAcc = new UserAccountRecord
                {
                    Username = user,
                    Password = pass,
                    SimbriefUsername = simbrief,
                    Role = "newbie",
                    IsApproved = false
                };

                list.Add(newAcc);
                File.WriteAllText(dbFilePath, JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true }));

                MessageBox.Show("Kayıt başarılı! Hesabınız 'newbie' rolü ile oluşturuldu ve admin onayına gönderildi. Onaylandıktan sonra giriş yapabilirsiniz.", "Başarılı", MessageBoxButton.OK, MessageBoxImage.Information);
                TabLogin_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kayıt hatası: " + ex.Message);
            }
        }
    }
}